import axios from "axios";

const tripForm = document.querySelector("#trip-submission-form");
const destinationInput = document.querySelector("#location-field");
const travelDateInput = document.querySelector("#journey-date-field");

const destinationError = document.querySelector("#location-error-message");
const dateError = document.querySelector("#date-error-message");

const handleFormSubmission = async (event) => {
    event.preventDefault();
    console.log("Processing form submission");

    if (!validateInputs()) {
        return;
    }

    const locationData = await retrieveLocationData();
    if (locationData && locationData.error) {
        destinationError.innerHTML = `<i class="bi bi-exclamation-circle-fill me-2"></i>${locationData.message}`;
        destinationError.style.display = "block";
        return;
    }

    const { longitude, latitude, cityName } = locationData;
    const selectedDate = travelDateInput.value;

    if (!selectedDate) {
        console.log("A travel date must be provided");
        dateError.innerHTML = `<i class="bi bi-exclamation-circle-fill me-2"></i>A travel date must be provided`;
        dateError.style.display = "block";
        return;
    }

    const daysRemaining = calculateDaysRemaining(selectedDate);
    const weatherInfo = await fetchWeatherInfo(longitude, latitude, daysRemaining);
    if (weatherInfo && weatherInfo.error) {
        dateError.innerHTML = `<i class="bi bi-exclamation-circle-fill me-2"></i>${weatherInfo.message}`;
        dateError.style.display = "block";
        return;
    }

    const cityImage = await fetchCityImage(cityName);
    updateInterface(daysRemaining, cityName, cityImage, weatherInfo);
};

const validateInputs = () => {
    destinationError.style.display = "none";
    dateError.style.display = "none";
    
    if (!destinationInput.value) {
        destinationError.innerHTML = `<i class="bi bi-exclamation-circle-fill me-2"></i>Please enter a destination`;
        destinationError.style.display = "block";
        return false;
    }
    if (!travelDateInput.value) {
        dateError.innerHTML = `<i class="bi bi-exclamation-circle-fill me-2"></i>Please select a travel date`;
        dateError.style.display = "block";
        return false;
    }
    return true;
};

const retrieveLocationData = async () => {
    const response = await axios.post("http://localhost:8000/getLocation", {
        location: destinationInput.value,
    });
    return response.data;
};

const fetchWeatherInfo = async (longitude, latitude, daysRemaining) => {
    const response = await axios.post("http://localhost:8000/getWeather", {
        longitude,
        latitude,
        daysRemaining,
    });
    return response.data;
};

const fetchCityImage = async (cityName) => {
    const response = await axios.post("http://localhost:8000/getCityImage", {
        cityName,
    });
    return response.data.image;
};

const calculateDaysRemaining = (date) => {
    const current = new Date();
    const tripDate = new Date(date);
    return Math.ceil((tripDate - current) / (1000 * 3600 * 24));
};

const updateInterface = (daysRemaining, cityName, image, weatherInfo) => {
    document.querySelector("#days-left").innerHTML = `Your trip starts in ${daysRemaining} days`;
    document.querySelector(".destination-name").innerHTML = `Destination: ${cityName}`;
    document.querySelector(".weather-details").innerHTML = `Weather: ${weatherInfo.description}`;
    document.querySelector(".temperature-info").innerHTML = `Temperature: ${weatherInfo.temp}°C`;
    document.querySelector(".location-image").innerHTML = `<img src="${image}" alt="City view">`;
    document.querySelector(".travel-details").style.display = "block";
};

tripForm.addEventListener("submit", handleFormSubmission);
