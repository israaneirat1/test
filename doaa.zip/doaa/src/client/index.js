
import "./public/style/style.scss"

import { handleSubmit } from "./script/handleForm";


export {
    handleSubmit
}