const axios = require("axios");

const getCityImage = async (city, key) => {
    const { data } = await axios.get(`https://pixabay.com/api/?key=${key}&q=${city}&image_type=photo`);
    return data.hits[0] ? { image: data.hits[0].webformatURL } : { image: "https://source.unsplash.com/random/640x480?city" };
};

module.exports = { getCityImage };
