const axios = require("axios");

const getWeatherInfo = async (longitude, latitude, daysRemaining, key) => {
    if (daysRemaining < 0) {
        return { message: "Date cannot be in the past", error: true };
    }
    
    const endpoint = daysRemaining <= 7 ? `current` : `forecast/daily`;
    const { data } = await axios.get(`https://api.weatherbit.io/v2.0/${endpoint}?lat=${latitude}&lon=${longitude}&units=M&key=${key}`);
    
    const latestData = data.data[data.data.length - 1];
    return {
        description: latestData.weather.description,
        temp: latestData.temp,
        max_temp: latestData.app_max_temp,
        min_temp: latestData.app_min_temp,
    };
};

module.exports = { getWeatherInfo };
