const axios = require("axios");

const getLocationDetails = async (city, username) => {
    const { data } = await axios.get(`https://secure.geonames.org/searchJSON?q=${city}&maxRows=1&username=${username}`);
    
    if (!data.geonames.length) {
        return { message: "No city found with that name", error: true };
    }
    return data.geonames[0];
};

module.exports = { getLocationDetails };
